
package com.example.hesabdari.inventory

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun InventoryScreen() {
    var name by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    val productList = remember { mutableStateListOf<Product>() }
    var nextId by remember { mutableStateOf(1) }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("مدیریت انبار", style = MaterialTheme.typography.titleLarge)

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("نام کالا") },
            modifier = Modifier.fillMaxWidth()
        )

        Row {
            OutlinedTextField(
                value = quantity,
                onValueChange = { quantity = it },
                label = { Text("تعداد") },
                modifier = Modifier.weight(1f).padding(end = 4.dp)
            )
            OutlinedTextField(
                value = price,
                onValueChange = { price = it },
                label = { Text("قیمت") },
                modifier = Modifier.weight(1f).padding(start = 4.dp)
            )
        }

        Button(
            onClick = {
                if (name.isNotBlank() && quantity.isNotBlank() && price.isNotBlank()) {
                    productList.add(Product(nextId++, name, quantity.toInt(), price.toDouble()))
                    name = ""
                    quantity = ""
                    price = ""
                }
            },
            modifier = Modifier.padding(top = 8.dp)
        ) {
            Text("افزودن کالا")
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(productList.size) { index ->
                val product = productList[index]
                Text("${product.name} - ${product.quantity} عدد - ${product.price} تومان")
            }
        }
    }
}
