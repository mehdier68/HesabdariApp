
package com.example.hesabdari.invoice

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

object InvoicePdfGenerator {
    fun generatePdf(context: Context, invoice: Invoice, file: File) {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint()
        paint.textSize = 16f

        var y = 50
        canvas.drawText("فاکتور", 250f, y.toFloat(), paint)
        y += 40
        canvas.drawText("مشتری: ${invoice.customerName}", 40f, y.toFloat(), paint)
        y += 30
        canvas.drawText("تاریخ: ${invoice.date}", 40f, y.toFloat(), paint)
        y += 30

        for (item in invoice.items) {
            canvas.drawText("${item.name} - ${item.quantity} عدد × ${item.unitPrice} = ${item.total}", 40f, y.toFloat(), paint)
            y += 25
        }

        y += 20
        canvas.drawText("جمع کل: ${invoice.totalAmount}", 40f, y.toFloat(), paint)

        pdfDocument.finishPage(page)
        file.parentFile?.mkdirs()
        pdfDocument.writeTo(FileOutputStream(file))
        pdfDocument.close()
    }
}
