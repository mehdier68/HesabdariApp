
package com.example.hesabdari

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.hesabdari.ui.theme.HesabdariTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HesabdariTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainMenu()
                }
            }
        }
    }
}

@Composable
fun MainMenu() {
    val menuItems = listOf(
        "تراکنش‌ها",
        "فاکتور",
        "انبار",
        "بدهکاران"
    )

    Column(modifier = Modifier.padding(16.dp)) {
        Text("نرم‌افزار حسابداری", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))
        menuItems.forEach { item ->
            Text(
                text = item,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { }
                    .padding(12.dp),
                style = MaterialTheme.typography.bodyLarge
            )
            Divider()
        }
    }
}
