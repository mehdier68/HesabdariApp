
package com.example.hesabdari.debtor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DebtorScreen() {
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    val debtors = remember { mutableStateListOf<Debtor>() }
    var nextId by remember { mutableStateOf(1) }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("مدیریت بدهکاران", style = MaterialTheme.typography.titleLarge)

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("نام مشتری") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = amount,
            onValueChange = { amount = it },
            label = { Text("مبلغ بدهی") },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )

        Button(
            onClick = {
                if (name.isNotBlank() && amount.isNotBlank()) {
                    debtors.add(Debtor(nextId++, name, amount.toDouble()))
                    name = ""
                    amount = ""
                }
            },
            modifier = Modifier.padding(top = 8.dp)
        ) {
            Text("ثبت بدهکار")
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(debtors.size) { index ->
                val debtor = debtors[index]
                Text("${debtor.name} - ${debtor.amount} تومان")
            }
        }
    }
}
