
package com.example.hesabdari.invoice

import android.content.Context
import android.graphics.*
import java.io.File
import java.io.FileOutputStream

object InvoiceImageGenerator {
    fun generateImage(context: Context, invoice: Invoice, file: File) {
        val width = 800
        val height = 1200
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint()
        paint.color = Color.BLACK
        paint.textSize = 36f

        var y = 80
        canvas.drawText("فاکتور", 320f, y.toFloat(), paint)
        y += 60
        canvas.drawText("مشتری: ${invoice.customerName}", 50f, y.toFloat(), paint)
        y += 50
        canvas.drawText("تاریخ: ${invoice.date}", 50f, y.toFloat(), paint)
        y += 50

        for (item in invoice.items) {
            canvas.drawText("${item.name} - ${item.quantity} × ${item.unitPrice} = ${item.total}", 50f, y.toFloat(), paint)
            y += 40
        }

        y += 40
        canvas.drawText("جمع کل: ${invoice.totalAmount}", 50f, y.toFloat(), paint)

        file.parentFile?.mkdirs()
        val out = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        out.flush()
        out.close()
    }
}
