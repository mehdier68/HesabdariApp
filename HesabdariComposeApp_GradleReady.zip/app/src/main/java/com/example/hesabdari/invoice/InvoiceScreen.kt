
package com.example.hesabdari.invoice

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun InvoiceScreen() {
    val items = remember {
        mutableStateListOf(
            InvoiceItem("کالا ۱", 2, 50000.0),
            InvoiceItem("کالا ۲", 1, 80000.0)
        )
    }

    val invoice = remember {
        Invoice(
            customerName = "مشتری تست",
            date = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date()),
            items = items
        )
    }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("فاکتور", style = MaterialTheme.typography.headlineSmall)
        Text("مشتری: ${invoice.customerName}")
        Text("تاریخ: ${invoice.date}")
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn {
            items(invoice.items.size) { index ->
                val item = invoice.items[index]
                Text("${item.name} - ${item.quantity} عدد × ${item.unitPrice} تومان = ${item.total}")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("جمع کل: ${invoice.totalAmount} تومان", style = MaterialTheme.typography.titleMedium)
    }
}
