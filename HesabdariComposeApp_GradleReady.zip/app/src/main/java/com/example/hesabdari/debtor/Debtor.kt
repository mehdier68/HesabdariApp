
package com.example.hesabdari.debtor

data class Debtor(
    val id: Int,
    val name: String,
    val amount: Double
)
