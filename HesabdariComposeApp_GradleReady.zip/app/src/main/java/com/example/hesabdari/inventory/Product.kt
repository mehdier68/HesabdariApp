
package com.example.hesabdari.inventory

data class Product(
    val id: Int,
    val name: String,
    val quantity: Int,
    val price: Double
)
