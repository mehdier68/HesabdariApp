
package com.example.hesabdari.invoice

data class InvoiceItem(
    val name: String,
    val quantity: Int,
    val unitPrice: Double
) {
    val total: Double get() = quantity * unitPrice
}

data class Invoice(
    val customerName: String,
    val date: String,
    val items: List<InvoiceItem>
) {
    val totalAmount: Double get() = items.sumOf { it.total }
}
